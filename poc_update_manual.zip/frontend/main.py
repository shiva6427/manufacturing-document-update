
import streamlit as st
import requests

st.title("Manufacturing Manual Updater")

uploaded_file = st.file_uploader("Upload Manual", type=["pdf"])
user_prompt = st.text_area("Enter updates or changes:")

if st.button("Update Manual"):
    if uploaded_file and user_prompt:
        files = {"file": uploaded_file.getvalue()}
        data = {"prompt": user_prompt}
        response = requests.post("http://localhost:8000/update_manual/", files=files, data=data)
        if response.status_code == 200:
            st.success("Manual updated successfully!")
            st.write("Summary of changes:")
            st.write(response.json()["summary"])
        else:
            st.error("Error updating manual.")
    else:
        st.error("Please upload a manual and enter a prompt.")
