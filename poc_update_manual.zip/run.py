
import subprocess

# Run FastAPI backend
subprocess.Popen(["uvicorn", "backend.app:app", "--reload"])

# Run Streamlit frontend
subprocess.run(["streamlit", "run", "frontend/main.py"])
