
from fastapi import FastAPI, UploadFile, Form
from backend.logic import process_manual

app = FastAPI()

@app.post("/update_manual/")
async def update_manual(file: UploadFile, prompt: str = Form(...)):
    content = await file.read()
    result = process_manual(content, prompt)
    return result
