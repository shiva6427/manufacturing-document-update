
from azure.identity import DefaultAzureCredential
from azure.ai.openai import OpenAIClient
from azure.search.documents import SearchClient

credential = DefaultAzureCredential()
search_client = SearchClient(endpoint="<your-search-endpoint>", credential=credential)
openai_client = OpenAIClient(endpoint="<your-openai-endpoint>", credential=credential)

def get_context_from_search(manual_text, prompt):
    # Use Azure AI Search to locate relevant sections
    search_results = search_client.search(prompt)
    context = " ".join([result["content"] for result in search_results])
    return context

def generate_update(context, prompt):
    # Use Azure OpenAI GPT-4o to generate updated content
    response = openai_client.get_completions(
        engine="<your-deployment-name>",
        prompt=f"Context: {context}\n\nUpdate manual based on: {prompt}",
        max_tokens=1000
    )
    return response.choices[0].text
