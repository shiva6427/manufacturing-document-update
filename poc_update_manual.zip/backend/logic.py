
from backend.azure_utils import get_context_from_search, generate_update
import pdfplumber
from PyPDF2 import PdfWriter, PdfReader

def process_manual(content, prompt):
    # Extract text from the PDF manual
    with pdfplumber.open(content) as pdf:
        manual_text = "".join([page.extract_text() for page in pdf.pages])

    # Use RAG to find context in the manual
    context = get_context_from_search(manual_text, prompt)

    # Generate the updated content
    updated_content = generate_update(context, prompt)

    # Replace the updated content in the manual
    updated_manual = update_manual_pdf(content, updated_content)

    # Generate summary of changes
    summary = "Summary of changes: Updated sections based on provided prompt."

    return {"summary": summary, "updated_manual": updated_manual}

def update_manual_pdf(content, updates):
    reader = PdfReader(content)
    writer = PdfWriter()

    # Assume updates contain page-level modifications
    for page in reader.pages:
        writer.add_page(page)

    # Write updated content back
    updated_pdf = "/mnt/data/data/updated_manual.pdf"
    with open(updated_pdf, "wb") as f:
        writer.write(f)

    return updated_pdf
